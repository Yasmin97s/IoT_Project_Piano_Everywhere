#pragma once

#include "MyIncludes.h"
#include "Detector.h"
#include <algorithm>

using std::string;



class PianoDetector : Detector {
private:
	//private final static String TAG = PianoDetector.class.getSimpleName();
	static const string TAG;
	//private final Mat mHSVMat = new Mat();
	const Mat mHSVMat;
	const Mat mMaskMat;

	//private final Scalar lowerThreshold = new Scalar(0, 0, 100);
	const Scalar lowerThreshold = Scalar(0, 0, 100);
	//private final Scalar upperThreshold = new Scalar(179, 255, 255);
	const Scalar upperThreshold = Scalar(179, 255, 255);

	const int whiteKeySizeLower = 1000;
	const int whiteKeySizeUpper = 12500;

	const int blackKeySizeLower = 500;
	const int blackKeySizeUpper = 5000;

	vector<MatOfPoint> whiteKeysOutLMOP;
	vector<MatOfPoint> blackKeysOutLMOP;

	vector<MatOfPoint> getContoursBySizeRange(vector<MatOfPoint> contours, int lower, int upper) {
		vector<MatOfPoint> newContours;
		for (int i = 0; i < contours.size(); i++) {
			int my_area = contourArea(contours.at(i));
			if ( my_area >= lower && my_area <= upper ) {
				newContours.push_back(contours.at(i));
			}
		}
		return newContours;
	}
	

	static bool compareContourAreas(MatOfPoint &contour1, MatOfPoint &contour2) {
		double i = fabs(contourArea(cv::Mat(contour1)));
		double j = fabs(contourArea(cv::Mat(contour2)));
		return (i < j);
	}

	static bool compareContourAreasReverse(MatOfPoint &contour1, MatOfPoint &contour2) {
		double i = fabs(contourArea(cv::Mat(contour1)));
		double j = fabs(contourArea(cv::Mat(contour2)));
		return (i > j);
	}

	vector<MatOfPoint> sortPianoKeys(vector<MatOfPoint> contours, bool reverse) {
		if (reverse) {
			std::sort(contours.begin(), contours.end(), compareContourAreasReverse);
		}
		else {
			std::sort(contours.begin(), contours.end(), compareContourAreas);
		}
		return contours;
	}

public:
	//public void apply(final Mat src, final Mat dst) {
	void apply(const Mat src, const Mat dst) {
		vector<MatOfPoint> mWhiteContoursLMOP;
		vector<MatOfPoint> mWhiteKeysLMOP;

		vector<MatOfPoint> mBlackContoursLMOP;
		vector<MatOfPoint> mBlackKeysLMOP;

		vector<Point> mWhiteKeysLP;
		MatOfPoint mWhiteKeysMOP;

		MatOfInt hullMOI;

		MatOfPoint mPianoMaskMOP;
		vector<MatOfPoint> mPianoMaskLMOP;
		Mat mPianoMaskMat(mMaskMat.size(), mMaskMat.type(), Scalar(0));

		
		// 1. Convert the image to HSV color space
		cvtColor(src, mHSVMat, COLOR_RGB2HSV);

		// 2. Apply threshold to detect white piano keys
		inRange(mHSVMat, lowerThreshold, upperThreshold, mMaskMat);

		
		// 3. Perform erosion
		//Imgproc.erode(mMaskMat, mMaskMat, new Mat());
		//erode(mMaskMat, mMaskMat, Mat()); //(original is commented)

		// 4. Find contours
		//Imgproc.findContours(mMaskMat, mWhiteContoursLMOP, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
		findContours(mMaskMat, mWhiteContoursLMOP, Mat(), RETR_LIST, CHAIN_APPROX_SIMPLE);

		
		// 5. If no contours detected, return.
		if (mWhiteContoursLMOP.size() == 0) {
			cout << TAG << ": No white contours found!" << endl;
			return;
		}

		
		// 7. Get contours that are within certain contour size range
		mWhiteKeysLMOP = getContoursBySizeRange(mWhiteContoursLMOP, whiteKeySizeLower, whiteKeySizeUpper);

		// 8. Reduce number of points of each contour using DP algorithm
		for (int i = 0; i < mWhiteKeysLMOP.size(); i++) {
			//mWhiteKeysLMOP.set(i, reduceContourPoints(mWhiteKeysLMOP.get(i)));
			mWhiteKeysLMOP.at(i) = reduceContourPoints(mWhiteKeysLMOP.at(i));
		}

		
		// 9. Eliminate contours that have less than 6 points or more than 8 points

		// 10. If no contours, just return
		if (mWhiteKeysLMOP.size() == 0) {
			cout << TAG << ": No white keys found!" << endl;
			return;
		}

		
		// 11. Draw white keys
		drawAllContours(dst, mWhiteKeysLMOP, Colors::mLineColorBlue, -1);
		
		
		// 12. Get convex hull of piano
		//// 12a. Convert LMOP to LP
		for (int i = 0; i < mWhiteKeysLMOP.size(); i++) {
			//mWhiteKeysLP.addAll(mWhiteKeysLMOP.get(i).toList());
			MatOfPoint myElement = mWhiteKeysLMOP.at(i);
			mWhiteKeysLP.insert(mWhiteKeysLP.end(), myElement.begin(), myElement.end());
		}

		//// 12b. Convert LP to MOP
		//mWhiteKeysMOP.fromList(mWhiteKeysLP);
		mWhiteKeysMOP = Mat(mWhiteKeysLP);

		//12a+b. Convert LMOP to MOP
		//for (int i = 0; i < mWhiteKeysLMOP.size(); i++) {
		//	//mWhiteKeysLP.addAll(mWhiteKeysLMOP.get(i).toList());
		//	MatOfPoint myElement = mWhiteKeysLMOP.at(i);
		//	mWhiteKeysMOP.insert(mWhiteKeysMOP.end(), myElement.begin(), myElement.end());
		//}

		// 12c. Get convex hull
		convexHull(mWhiteKeysMOP, hullMOI);

		// 12d. Convert hullMOI to MOP
		//mPianoMaskMOP = hullToContour(hullMOI, mWhiteKeysMOP);
		mPianoMaskMOP = hullToContour(hullMOI, mWhiteKeysMOP);

		// 12e. Convert MOP to LMOP
		mPianoMaskLMOP.push_back(mPianoMaskMOP);

		
		// 13. Create piano mask mat
		drawContours(mPianoMaskMat, mPianoMaskLMOP, 0, Colors::mLineColorWhite, -1);
		inRange(mHSVMat, lowerThreshold, upperThreshold, mMaskMat);

		
		// 14. Dilate image 3 times to remove piano lines
		dilate(mMaskMat, mMaskMat, Mat());
		dilate(mMaskMat, mMaskMat, Mat());
		dilate(mMaskMat, mMaskMat, Mat());

		// 15. Invert piano mask
		bitwise_not(mMaskMat, mMaskMat);

		// 16. Apply piano mask to binary image
		mMaskMat.copyTo(mPianoMaskMat, mPianoMaskMat);

		// 17. Find black key contours
		findContours(mPianoMaskMat, mBlackContoursLMOP, Mat(), RETR_LIST, CHAIN_APPROX_SIMPLE);

		// 18. If no contours detected, return.
		if (mBlackContoursLMOP.size() == 0) {
			//Log.i(TAG, "No black contours found!");
			cout << TAG << ": No black contours found!" << endl;
			return;
		}

		// 19. Get contours that are within certain contour size range
		mBlackKeysLMOP = getContoursBySizeRange(mBlackContoursLMOP, blackKeySizeLower, blackKeySizeUpper);

		// 20. Reduce number of points of each contour using DP algorithm
		for (int i = 0; i < mBlackKeysLMOP.size(); i++) {
			mBlackKeysLMOP.at(i) = reduceContourPoints(mBlackKeysLMOP.at(i));
		}

		// 21. If no contours, just return
		if (mBlackKeysLMOP.size() == 0) {
			//Log.i(TAG, "No black key found!");
			cout << TAG << ": No black keys found!" << endl;
			return;
		}

		// 22. Draw black key contours
		drawAllContours(dst, mBlackKeysLMOP, Colors::mLineColorRed, -1);

		// 25. Sort piano keys and update whiteKeysOutLMOP and blackKeysOutLMOP
		whiteKeysOutLMOP = sortPianoKeys(mWhiteKeysLMOP, true);
		blackKeysOutLMOP = sortPianoKeys(mBlackKeysLMOP, true);
		
	}

	vector<MatOfPoint> getWhiteKeysLMOP() {
		return whiteKeysOutLMOP;
	}

	vector<MatOfPoint> getBlackKeysLMOP() {
		return blackKeysOutLMOP;
	}

	void drawAllContours(const Mat dst, vector<MatOfPoint> contours, Scalar color, int thickness) {
		for (int i = 0; i < contours.size(); i++) {
			drawContours(dst, contours, i, color, thickness);
		}
	}
};

const string PianoDetector::TAG("PianoDetector");