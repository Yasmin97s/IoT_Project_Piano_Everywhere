#pragma once

#include "MyIncludes.h"

//contours:	Detected contours.
//			Each contour is stored as a vector of points
//			(e.g. std::vector<std::vector<cv::Point> >).

using namespace cv;

class Detector {
public:
	void apply(const Mat src, const Mat dst) {
	}

	//void drawAllContours(const Mat dst, list<MatOfPoint> contours) {
	void drawAllContours(const Mat dst, vector<MatOfPoint> contours) {
		for (int i = 0; i < contours.size(); i++) {
			cv::drawContours(dst, contours, i, Colors::mLineColorGreen, -1);
			//Imgproc.drawContours(dst, contours, i, Colors.mLineColorGreen, -1);

		}
	}

	//public int findLargestContourIndex(List<MatOfPoint> contours) {
	int findLargestContourIndex(vector<MatOfPoint> contours) {
		int index = -1;
		double maxArea = 0;

		for (int i = 0; i < contours.size(); i++) {
			double thisArea = contourArea(contours.at(i));
			if (thisArea > maxArea) {
				index = i;
				maxArea = thisArea;
			}
		}

		return index;
	}

	//public MatOfPoint reduceContourPoints(MatOfPoint contours) {
	MatOfPoint reduceContourPoints(MatOfPoint contours) {
		//MatOfPoint2f approxCurve = new MatOfPoint2f();
		MatOfPoint approxCurve;
		//MatOfPoint2f contour2f(contours.toArray());

		double approxDistance = arcLength(contours, true) * 0.01;

		approxPolyDP(contours, approxCurve, approxDistance, true);

		MatOfPoint points(approxCurve);

		return points;
	}

	/*
	template<class T>
	Mat VectorOfVector_to_Mat(vector<vector<T>> my_VecMatOfPoint) {
		cv::Mat my_Mat(my_VecMatOfPoint.size(), my_VecMatOfPoint.at(0).size(), CV_64FC1);
		for (int i = 0; i < my_Mat.rows; ++i)
			for (int j = 0; j < my_Mat.cols; ++j)
				my_Mat.at<T>(i, j) = my_VecMatOfPoint.at(i).at(j);
	}
	*/

	// todo: impelemt "hullToContour" function
	// maybe not needed: in c++, convex hull is a contour
	
	
	MatOfPoint hullToContour(MatOfInt hullMOI, MatOfPoint contourMOP) {

		Mat mopOut((int)hullMOI.size().height, 1, CV_32SC2);
		//mopOut.create((int) hullMOI.size().height, 1, CV_32SC2);
		
		for(int i=0; i<hullMOI.size().height; i++) {
			
			int index = (int) hullMOI.at<int>(i,0);
			Point point = { contourMOP.at<Point>(index,0).x, contourMOP.at<Point>(index,0).y };
			
			mopOut.at<Point>(i, 0) = point;
			
			//Point x = new Point(point[0], point[1]);
			//Log.i(TAG, "Point " + i + ": " + point[0] + ", " + point[1]);
		}
		
		return mopOut;
	}
	
};