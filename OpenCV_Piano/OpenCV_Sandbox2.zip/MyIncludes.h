#pragma once

#include "Colors.h"
#include <opencv2/core/types.hpp>

//http://ninghang.blogspot.com/2012/11/list-of-mat-type-in-opencv.html
//https://stackoverflow.com/questions/26502912/opencv-mat-for-integer-types-only
//https://docs.opencv.org/2.4/modules/core/doc/basic_structures.html

//import java.util.ArrayList;
using std::vector;
//import java.util.List;
/*use vector instead of list*/
/*#include <list>
using std::list;*/

//import org.opencv.core.CvType;
/*???*/
//import org.opencv.core.Mat;
#include <opencv2/core/types.hpp>
//import org.opencv.core.MatOfInt;
typedef Mat_<int> MatOfInt;
//typedef vector<int> MatOfInt;

//import org.opencv.core.MatOfPoint;
//typedef vector<Point> MatOfPoint;
typedef Mat_<Point> MatOfPoint;
//import org.opencv.core.MatOfPoint2f;
/*typedef vector<Point2f> MatOfPoint2f;*/
//import org.opencv.core.Point;
/*typedef Point Point;*/
//import org.opencv.imgproc.Imgproc;
#include <opencv2/imgproc.hpp>
/*
Use the OpenCV function cv::findContours
Use the OpenCV function cv::drawContours
*/

using namespace cv;