#pragma once

#include "MyIncludes.h"
#include "Detector.h"

class HandDetector : Detector {

private:
	static const string TAG;

	const int handArea = 500;

	const int lowerHue = 3;
	const int upperHue = 33;

	const Scalar lowerThreshold = Scalar(lowerHue, 50, 50);
	const Scalar upperThreshold = Scalar(upperHue, 255, 255);

	const Mat mMat;

	vector<MatOfPoint> contoursOut;

	Point lowestPoint;


	Point findHighestPoint(MatOfPoint contour) {
		Point highest(0, 0);

		for (int i = 0; i < contour.rows; i++) {
			if (contour.at<Point>(i, 0).y > highest.y) {
				highest.x = contour.at<Point>(i, 0).x;
				highest.y = contour.at<Point>(i, 0).y;
			}
		}

		return highest;
	}

	Point findLowestPoint(MatOfPoint contour) {
		Point lowest(5000,5000);
		
		for (int i = 0; i < contour.rows; i++) {
			if (contour.at<Point>(i, 0).y < lowest.y) {
				lowest.x = contour.at<Point>(i, 0).x;
				lowest.y = contour.at<Point>(i, 0).y;
			}
		}

		return lowest;
	}


	
	//	public void apply(final Mat dst, final Mat src) {
	void apply(const Mat dst, const Mat src) {
		//	List<MatOfPoint> contours = new ArrayList<MatOfPoint>();
		vector<MatOfPoint> contours;

		// 1. Convert image to HSV color space
		//Imgproc.cvtColor(src, mMat, Imgproc.COLOR_RGB2HSV);
		cvtColor(src, mMat, COLOR_RGB2HSV);

		// 2. Apply static skin color threshold
		//Core.inRange(mMat, lowerThreshold, upperThreshold, mMat);
		inRange(mMat, lowerThreshold, upperThreshold, mMat);

		// 3a. Perform dilation
		//	//Imgproc.dilate(mMat, mMat, new Mat());
		// (commented in source)

		// 3a. Perform erosion
		//	Imgproc.erode(mMat, mMat, new Mat());
		erode(mMat, mMat, Mat());

		// 4. Find contours
		//	Imgproc.findContours(mMat, contours, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
		findContours(mMat, contours, Mat(), RETR_LIST, CHAIN_APPROX_SIMPLE);

		// 5. If no contours, return
		if (contours.size() == 0) {
			//Log.i(TAG, "No contours found");
			//todo: how to =null?
			//lowestPoint = null;
			return;
		}

		// 6. Find index of the largest contour, assume that is the hand
		int largestContourIndex = findLargestContourIndex(contours);

		// 7. If index equals -1, return
		if (largestContourIndex == -1 || contourArea(contours.at(largestContourIndex)) < handArea) {
			//Log.i(TAG, "No hand detected");
			//todo: how to =null?
			lowestPoint = Point(-1,-1);
			return;
		};

		// 8. Reduce number of points using DP algorithm
		vector<MatOfPoint> reducedHandContours;
		reducedHandContours.push_back(reduceContourPoints(contours.at(largestContourIndex)));

		//Log.i(TAG, Double.toString(Imgproc.contourArea(reducedHandContours.get(0))));
		cout << TAG << ": contourArea(reducedHandContours.at(0)) = " << contourArea(reducedHandContours.at(0)) << endl;

		// 9. Get convex hull of hand
		MatOfInt hullMOI;
		convexHull(reducedHandContours.at(0), hullMOI);

		// 10. Convert hull to contours
		vector<MatOfPoint> hullContourLMOP;
		hullContourLMOP.push_back(hullToContour(hullMOI, reducedHandContours.at(0)));

		// 11. Draw convex hull points
		/*for(int i=0; i<hullContourLMOP.get(0).rows(); i++) {
			Point p = new Point(hullContourLMOP.get(0).get(i, 0));
			Imgproc.circle(dst, p, 10, Colors.mLineColorGreen, 2);
		}*/
		/* Original is commented */

		// 12. Find convex hull points that are within piano area
		// (Create new method)
		// getPointsByRegion();
		/* Original is commented */

		//	// 13. Reduce convex hull points to (maximum) 5 distinct points
		//	// to correspond to 5 finger tips (Create new method)
		//	// getFingerTipPoints();
		/* Original is commented */

		// 11. Get convexity defects
		Mat_<Vec4i> convDefMOI4;
		convexityDefects(reducedHandContours.at(0), hullMOI, convDefMOI4);
		// Draw contours
		//Imgproc.drawContours(dst, contours, largestContourIndex, Colors.mLineColorGreen, 2);
		//Imgproc.drawContours(dst, reducedHandContours, 0, Colors.mLineColorRed, 2);
		drawContours(dst, hullContourLMOP, 0, Colors::mLineColorBlue, 2);

		// Draw convexity defect points
		if (!convDefMOI4.empty()) {
			vector<int> cdList = convDefMOI4.reshape(0,1);

			vector<Point> data_v = reducedHandContours.at(0).reshape(0,1);
			Point* data = &data_v[0];
			//Point data[] = reducedHandContours.at(0);

			for (int i = 0; i < cdList.size(); i += 4) {
				Point start = data[cdList.at(i)];
				Point end = data[cdList.at(i + 1)];
				Point defect = data[cdList.at(i + 2)];

				//Imgproc.circle(dst, start, 15, Colors.mLineColorGreen, 2);
				//Imgproc.circle(dst, end, 20, Colors.mLineColorRed, 2);
				//Imgproc.circle(dst, defect, 10, Colors.mLineColorYellow, 2);
			}
		}

		// Find lowest point
		lowestPoint = findHighestPoint(hullContourLMOP.at(0));
		//lowestPoint = findLowestPoint(hullContourLMOP.get(0));

		// Draw lowest point
		if (lowestPoint != Point(-1,-1)) {
			circle(dst, lowestPoint, 5, Colors::mLineColorRed, -1);
		}
	}


	vector<MatOfPoint> getHandContours() {
		return contoursOut;
	}

	Point getLowestPoint() {
		return lowestPoint;
	}
};

const string HandDetector::TAG("HandDetector");